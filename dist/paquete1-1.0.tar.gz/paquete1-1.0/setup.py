from setuptools import setup 
setup(

    name="paquete1",
    version="1.0",
    description="Paquete para entrega 2",
    author="Naiku",
    packages=["paquete1"],
)

